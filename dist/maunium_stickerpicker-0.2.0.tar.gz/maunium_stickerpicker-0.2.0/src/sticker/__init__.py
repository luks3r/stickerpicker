__version__ = "0.1.0+dev"
__author__ = "Tulir Asokan <tulir@maunium.net>"
